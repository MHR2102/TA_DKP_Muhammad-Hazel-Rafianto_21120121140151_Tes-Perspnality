
package Assign1;
import java.util.Scanner;
/*
Nama : Farhan Ryan Rafli
NIM : 21120121130057
*/
public class P2 {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);  
        System.out.print("Enter number of inputs: ");
        int input = sc.nextInt();
        
        for (int i = 0; i < input; i++) {
            System.out.print("Enter input integer: ");    //Masukkan Input
            int integer = sc.nextInt();
            String awal = "",                             //Inisialisasi
                   akhir = "";
            
            if (integer >= 0 && integer <=99){            //Batas variabel "integer" 
            switch(integer % 10){                         //Mencari awal dengan mengambil satuan dari input
                case 0 :                                   
                    awal="zero";
                    break;
                case 1 :
                    awal="one";
                    break;
                case 2 :
                    awal="two";
                    break;
                case 3 :
                    awal="three";                         //Lalu, setiap satuan memiliki outputnya masing-masing
                    break;                                //Output dimasukkan kedalam variabel "awal"
                case 4 :
                    awal="four";
                    break;
                case 5:
                    awal="five";
                    break;
                case 6:
                    awal="six";
                    break;
                case 7:
                    awal="seven";
                    break;
                case 8: 
                    awal="eight";
                    break;
                case 9:
                    awal="nine";
                    break;
            }
            switch((integer - (integer % 10))/10){        //Mencari akhir dengan mengambil puluhan dari input
                case 1:                                   
                    akhir="one";
                    break;
                case 2:
                    akhir="two";
                    break;
                case 3:
                    akhir="three";
                    break;
                case 4:
                    akhir="four";
                    break;
                case 5:                                   //Lalu, setiap puluhan memiliki outputnya masing-masing
                    akhir="five";                         //Output dimasukkan kedalam variabel "akhir"
                    break;
                case 6:
                    akhir="six";
                    break;
                case 7:
                    akhir="seven";
                    break;
                case 8: 
                    akhir="eight";
                    break;
                case 9:
                    akhir="nine";
                    break;
            }
                System.out.println("Output: "+awal+" "+akhir);   //Memberikan hasil output       
            }   else if(integer>99){
                    System.out.println("Output: Error-input exceeds 99");
            }   else if(integer<0){
                    System.out.println("Output: Error-input less than 0");
            }
            
        }
    }
}
