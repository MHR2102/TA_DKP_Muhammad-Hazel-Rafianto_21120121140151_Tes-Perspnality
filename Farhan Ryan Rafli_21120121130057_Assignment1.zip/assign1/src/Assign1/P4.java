
package Assign1;

import java.util.Scanner;
/*
Nama : Farhan Ryan Rafli
NIM : 21120121130057
*/
public class P4 {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
        while(true){
            int total=0,temp,a;
            System.out.print("Enter integer number: "); //Masukkan input kedalam variable number
            int number = sc.nextInt();                  //"number" sebagai nilai ketetapan untuk perbandingan dalam if
            temp = number;                              //variable yang memiliki nilai yang sama dengan "number", variable ini akan sering berubah didalam loop
        
            while(temp>0){                              //Loop while ini berfungsi untuk MEMBALIKAN angka "number" yang sudah di input
            a = temp % 10;                              //"a" sebagai sisa bagi "temp"
            total = (total*10)+a;                       //"total" akan ditampung sampai loop selesai,awalan angka "total" akan berada di digit akhir "number" 
            temp = temp/10;                             //berfungsi untuk pindah ke digit berikutnya
            }
            
            if(number == -1){                           //Menghentikan program
                System.out.println("<Programs terminates>");
                break;
            }
            if (number == total){                       //Jika angka "number" sama dengan "total" yang telah dibalik
                System.out.println("Output: true");
            } else if (number != total){                //Jika angka "number" tidak sama dengan "total" yang telah dibalik
                System.out.println("Output: false");  
            }
            
            
        }    



    
    }
    
}
