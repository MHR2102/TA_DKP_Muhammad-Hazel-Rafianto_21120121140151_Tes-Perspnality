
package Assign1;
import java.util.Scanner;
/*
Nama : Farhan Ryan Rafli
NIM : 21120121130057
*/
public class P3 {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

           while(true){
           System.out.print("height: ");        
           int height = sc.nextInt();                       //Masukkan Input
           if (height>=1 && height<=9){
           for (int baris=1;baris<=height;baris++){         //Baris
               for (int spasi=height;spasi>baris;spasi--){  //Spasi agar bisa membuat bentuk segitiga
                   System.out.print("  ");   
               }       
                       int a=baris;                         
                       int tengah=a;
                       System.out.print(a+" ");                 //Output tepi kiri
                       if (a>1 && a<=height){
                            for (int i=1;i<=a-1;i++){       //Output isi kiri sampai tengah
                                tengah++;
                                if (tengah==10){
                                    tengah=0;
                               } 
                                System.out.print(tengah+" ");
                            }
                            for (int i=a;i-1>=1;i--){       //Output isi kanan sampai tepi kanan
                                tengah--;
                                System.out.print(tengah+" ");
                                if (tengah==0){
                                    tengah=10;
                               }
                            }   
                       } 
                       
                    System.out.println("");                //setelah Output di baris tertentu selesai, pindah baris 
                }
            }   else if (height==-1){                      //Menghentikan program
                    System.out.println("<Program terminates>");
                    break;
            }   else{
                    System.out.println("Error");
            }
        }
    }
}
