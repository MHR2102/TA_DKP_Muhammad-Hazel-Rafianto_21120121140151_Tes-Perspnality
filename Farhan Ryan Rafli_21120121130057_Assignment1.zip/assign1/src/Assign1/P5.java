
package Assign1;
import java.util.Scanner;
/*
Nama : Farhan Ryan Rafli
NIM : 21120121130057
*/
public class P5 {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
        System.out.println("x = -1<=x<=1");
        System.out.print("Masukkan nilai x: ");             //Masukkan input
        double x = sc.nextDouble();
        int n = 1;                                          //ketetapan untuk perpindahan tahap
        double kiri = 1.0/2;                                //Awalan perkalian pecahan kiri
        double result = x;                                  //Penampung hasil dengan awalan x
        double temp = n;                                    //Bilangan ganjil sesuai tahap
       
        if (x>=-1 && x<=1){
            while(n <= 7){                                   //Banyak penjumlahan
                temp = (n*2)-1;
            double kanan = (Math.pow(x, temp+2))/(temp+2);   //Perkalian pecahan kanan , pakai variable result agar x didalam Math.pow() tetap 
                result += (kiri)*(kanan);                    //Penjumlahan bertahap
                kiri*=(temp+2)/(temp+3);                     //Perkalian kiri untuk penjumlahan selanjutnya
            n++;                                             //Menuju ke tahap penjumlahan berikutnya
        }
        System.out.println("result: "+result);
        } else{                                              //Jika tidak sesuai dengan kondisi dalam if
            System.out.println("Try Again");
        }
    }
}
