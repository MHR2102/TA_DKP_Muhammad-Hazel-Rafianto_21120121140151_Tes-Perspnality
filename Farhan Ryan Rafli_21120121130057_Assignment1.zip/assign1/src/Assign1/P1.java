
package Assign1;
import java.util.Scanner;
/*
Nama : Farhan Ryan Rafli
NIM : 21120121130057
*/
public class P1 {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
        
    while (true){                                                       //Loop agar program bisa terulang
        System.out.print("Enter your Birth year: ");                    //Masukkan input
        int tahun = sc.nextInt();
        
            if (tahun % 12 == 0){                                       
                System.out.println("Your hororscope sign: Monkey");     
            } else if (tahun % 12 == 1){
                System.out.println("Your hororscope sign: Rooster");
            } else if (tahun % 12 == 2){
                System.out.println("Your hororscope sign: Dog");
            } else if (tahun % 12 == 3){
                System.out.println("Your hororscope sign: Pig");
            } else if (tahun % 12 == 4){
                System.out.println("Your hororscope sign: Rat");
            } else if (tahun % 12 == 5){
                System.out.println("Your hororscope sign: Cow");        //if dan else statement, dimana hororscope yang ditampilkan
            } else if (tahun % 12 == 6){                                //dari input yang dimasukkan sesuai dengan kondisi
                System.out.println("Your hororscope sign: Tiger");
            } else if (tahun % 12 == 7){
                System.out.println("Your hororscope sign: Rabbit");
            } else if (tahun % 12 == 8){
                System.out.println("Your hororscope sign: Dragon");
            } else if (tahun % 12 == 9){
                System.out.println("Your hororscope sign: Snake");
            } else if (tahun % 12 == 10){
                System.out.println("Your hororscope sign: Horse");
            } else if (tahun % 12 == 11){
                System.out.println("Your hororscope sign: Goat");
            }   
        
        if (tahun == -1) {                                              //Menghentikan Program
            System.out.println("<Program terminates>");
                break;
        }
    }
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
